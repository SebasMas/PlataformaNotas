package mundo;
import javax.swing.*;
import java.util.Arrays;

public class Curso {

    /* Constante para cantidad de estudiantes/notas */
    public static final int TOTAL_EST = 12;

    /*Atributos*/
    private double[] notas;

    /*Metodos*/

    public Curso(){
        notas = new double [TOTAL_EST];
        Arrays.fill(notas, 0.0);


    }

    /* Metodo para calcular promedio*/
    public double  promedio(){
        double promedio = 0;
        double sumaNotas = 0;
        for(double nota : notas){
            sumaNotas += nota;
        }

        promedio = sumaNotas / TOTAL_EST;
        return promedio;
    }

    /*Devuelve el número de estudiantes que estén por encima del promedio
     */
    public int darCantidadSobrePromedio(){
        double promedio = promedio();
        int EstudiantesM= 0;
        for(int i = 0; i< notas.length; i++){
            if (notas[i] > promedio){
                EstudiantesM++;
            }
        }
        return EstudiantesM;
    }

    public double darNota(int numEs){
        return notas[numEs-1];
    }

    /* Metodo para cambiar la nota de un estudiante que recibe la posición del estudiante y la nota*/
    public void cambiarNota(int numEs, double nota){
         notas[numEs - 1] = nota;
    }

    //Mostrar el promedio de los estudiantes con nota inferior a 3,0
    public double metodo1(){
        int perdidosE = 0;
        double suma = 0;
        for(int i = 0; i<notas.length; i++){
            if(notas[i]<3.0){
                perdidosE++;
                suma += notas[i];
            }
        }
        return suma/perdidosE;
    }

    public double metodo2(){
        int Ganadores = 0;
        double suma = 0;
        for(int i = 0; i<notas.length; i++){
            if(notas[i]>2.9 && notas[i]<= 5-0){
                Ganadores++;
                suma += notas[i];
            }
        }
        return suma/Ganadores;
    }



}

