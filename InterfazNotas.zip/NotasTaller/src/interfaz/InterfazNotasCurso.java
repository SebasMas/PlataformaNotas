 /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Libre
 * Ingenier�a de Sistemas
 *
 * Proyecto:
 * Ejercicio: n3_notasCurso
 * Autor: Equipo FP 2023
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package interfaz;
import mundo.Curso;

import java.awt.*;

import javax.swing.*;


/**
 * Esta es la ventana principal de la aplicaci�n.
 */
@SuppressWarnings("serial")
public class InterfazNotasCurso extends JFrame
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Clase principal del mundo.
     */
    private Curso curso;

    // -----------------------------------------------------------------
    // Atributos de la interfaz
    // -----------------------------------------------------------------

    /**
     * Panel banner de la aplicaci�n.
     */
    private PanelBanner panelBanner;

    /**
     * Panel imagen del curso.
     */
    private PanelImagen panelImagen;

    /**
     * Panel donde se muestran las notas.
     */
    private PanelDatos panelDatos;

    /**
     * Panel de opciones adicionales.
     */
    private PanelAdicionales panelAdicionales;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Construye la interfaz de notas del curso. <br>
     * <b>post: </b> Se inicializaron los componentes gr�ficos de la aplicaci�n.
     */
    public InterfazNotasCurso( )
    {
        setTitle( "Sistema de Manejo de Notas" );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        setSize( 700, 600 );

        // Crea la clase principal
        curso = new Curso( );
        // organizar el panel principal
        setLayout( new BorderLayout( ) );

        panelBanner = new PanelBanner( );
        add( panelBanner, BorderLayout.NORTH );

        panelImagen = new PanelImagen( );
        add( panelImagen, BorderLayout.WEST );

        panelDatos = new PanelDatos( this, Curso.TOTAL_EST );
        add( panelDatos, BorderLayout.CENTER );

        panelAdicionales = new PanelAdicionales( this );
        add( panelAdicionales, BorderLayout.SOUTH );

        setLocationRelativeTo( null );
        setResizable( false );
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Cambia la nota de un estudiante.
     * @param pEstudiante Estudiante a modificar. 1 <= pEstudiante <=12.
     */
    public void cambiarNota( int pEstudiante )
    {
        String notaStr = JOptionPane.showInputDialog( this, "Nueva nota:", "Nota", JOptionPane.QUESTION_MESSAGE );
        try
        {
            if( notaStr != null )
            {
                double nota = Double.parseDouble( notaStr );
                // valida el valor de nota
                if( nota < 0 || nota > 5 )
                {
                    JOptionPane.showMessageDialog( this, "La nota debe tener un valor entre 0.0 y 5.0", "Error", JOptionPane.ERROR_MESSAGE );

                }
                else
                {
                    // Cambia la nota
                    curso.cambiarNota( pEstudiante, nota );
                    // Repinta el panel
                    panelDatos.refrescarNota( pEstudiante, curso.darNota( pEstudiante ) );
                }
            }
        }
        catch( NumberFormatException e )
        {
            JOptionPane.showMessageDialog( this, "La nota debe tener un valor num�rico. (ej. 2.5)", "Error", JOptionPane.ERROR_MESSAGE );
        }
    }

    /**
     * Muestra el promedio en un mensaje de texto.
     */
    public void mostrarPromedio( )
    {
        JOptionPane.showMessageDialog( this, "Promedio: " + Double.toString( curso.promedio( ) ), "Promedio", JOptionPane.INFORMATION_MESSAGE );
    }

    /**
     * Muestra el n�mero de estudiantes con nota mayor al promedio.
     */
    public void mostrarMayores( )
    {
        JOptionPane.showMessageDialog( this, "N�mero de estudiantes con nota mayor al promedio: " + Integer.toString( curso.darCantidadSobrePromedio( ) ), "Estudiantes", JOptionPane.INFORMATION_MESSAGE );
    }

    // -----------------------------------------------------------------
    // Puntos de Extensi�n
    // -----------------------------------------------------------------

    /**
     * M�todo para la extensi�n 1.
     */
    public void reqFuncOpcion1( )
    {
        double resultado = curso.metodo1( );
        JOptionPane.showMessageDialog( this, resultado, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
    }

    /**
     * M�todo para la extensi�n 2.
     */
    public void reqFuncOpcion2()
    {
        double resultado = curso.metodo2( );
        JOptionPane.showMessageDialog( this, resultado, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
    }

    // -----------------------------------------------------------------
    // Main
    // -----------------------------------------------------------------

    /**
     * Ejecuta la aplicaci�n.
     * @param pArgs Par�metros de la ejecuci�n. No son necesarios.
     */
    public static void main( String[] pArgs )
    {
        try
        {
            // Unifica la interfaz para Mac y para Windows.
            UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName( ) );

            InterfazNotasCurso interfaz = new InterfazNotasCurso( );
            interfaz.setVisible( true );
        }
        catch( Exception e )
        {
            e.printStackTrace( );
        }
    }
}