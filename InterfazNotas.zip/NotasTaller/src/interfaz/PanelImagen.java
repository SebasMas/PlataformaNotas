 /**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Libre
 * Ingenier�a de Sistemas
 *
 * Proyecto:
 * Ejercicio: n3_notasCurso
 * Autor: Equipo FP
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package interfaz;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.Objects;

 /**
 * Panel de la imagen del curso.
 */
@SuppressWarnings("serial")
public class PanelImagen extends JPanel
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * Etiqueta usada para mostrar la imagen.
     */
    private JLabel etiquetaImagen;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Constructor del panel.
     */
    public PanelImagen( )
    {
        setBorder( new EmptyBorder( 3, 3, 3, 3 ) );

        etiquetaImagen = new JLabel();
        Image img= new ImageIcon("src/imagenes/imagenClase.jpg").getImage();
        ImageIcon img2=new ImageIcon(img.getScaledInstance(378, 300, Image.SCALE_SMOOTH));
        etiquetaImagen.setIcon(img2);

        JPanel panelBorde = new JPanel( );
        panelBorde.setBorder( new TitledBorder( "" ) );
        panelBorde.add( etiquetaImagen );
        add( panelBorde );
    }
}
